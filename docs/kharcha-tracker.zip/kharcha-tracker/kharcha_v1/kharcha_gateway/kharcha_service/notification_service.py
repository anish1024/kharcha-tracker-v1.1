# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: notification_service
# Status: contract_defined
# Parent: kharcha_service
# Protocol: module
# Layout: file
# Contract version: 0.3.0
# Dependencies:
#   - storage_interface
#   - notification
#   - notification_record
#   - notification_kind

# Notes:
# File: kharcha_service/notification_service.py. In-app notifications (FR-18); email / push
# delivery can later be added inside notify() without changing callers.

# Exports declared by YAML:
#   - notify
#   - list_notifications
#   - mark_notifications_read
