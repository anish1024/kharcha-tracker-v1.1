# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: flat_file
# Status: stub
# Parent: storage_service
# Protocol: class
# Layout: file
# Contract version: 0.0.0
# Dependencies:
#   - storage_interface
#   - group_record
#   - user_record
#   - expense_record
#   - payout_record
#   - settlement_round_record
#   - notification_record
#   - audit_log

# Notes:
# Database folder Path: kharcha-tracker/storage_service/flat_file_db/'. Create if this file does not exist yet. 
#
# Schema table files to read/write to:
# user_record - kharcha-tracker/storage_service/flat_file_db/user_records.json
# group_record - kharcha-tracker/storage_service/flat_file_db/group_records.json
# expense_record - kharcha-tracker/storage_service/flat_file_db/expense_records.json
# payout_record - kharcha-tracker/storage_service/flat_file_db/payout_records.json
# settlement_round_record - kharcha-tracker/storage_service/flat_file_db/settlement_round_records.json
# notification_record - kharcha-tracker/storage_service/flat_file_db/notification_records.json
# audit_log - kharcha-tracker/storage_service/flat_file_db/audit_logs.json
#
# Working: All data must be loaded as list<schema_record> in-memory for quick read/write. Every write should update in-memory list and immediately trigger file write to relevant schema table.
#
# Things to Consider:
# 1. ID generation: UUIDs. Record ID Format: UUID string in get_record
# 2. Schema Validation: Validate that schema parameter exists in registry before operations
# 3. ExpenseRecord Handling: Deep-copy nested objects during deserialisation; use json.dump() with default=str to handle serialisation. This is regarding DTOs ‘List<expense_payments>’ and ‘List<expense_share’ which will be JSON encoded strings stored for schema ‘ExpenseRecord.paid_by’ and ‘ExpenseRecord.expn_splt’ 
# 4. Transaction ID Generation: Auto-incrementing Unsigned Int 32-bit (using MAX_TRANSACTION_ID from constants = 4294967295)
# 5. Error Handling: Return success/failure with message format for all operations
# 6. In-Memory Storage Strategy: Multi-tier approach
# 	- Master tables (user, group): Fully loaded & cached
# 	- Transaction tables (expense, audit_log): Lazy-loaded based on group_id; limit max transactions per group
# 	- Pagination: Load in pages of 1000 records from file
# 7. Storage structure: Should records be stored as:
# 	- Flat JSON array: {“{id}: [{…}]}, where id is the record_id i.e. UUID
# 8. Soft delete implementation: Set is_deleted: true 
# 9. Audit log structure: Following structure is approved
# {
#     "id": ...,
#     "action": "CREATE|UPDATE|DELETE",
#     "table/schema: "...",
#     "user_id": ...,
#     "created_at": "...",
#     "old_value": {...},
#     "new_value": {...}
# }
# 10. Referential integrity: Must implement CASCADE delete for child records when parent is deleted
# 11. Search/filters: list_records() must support filters (by user_id, by group_id, by field values)
# 12. Import strategy: Relative imports (from .schema.*)
# 13. Deduplication rule: When same record.id exists in in-memory list, keep the newest (last) record
# 14. Schema registry: Want a schema_registry.json for mapping schema names to default classes
# 15. Constants: The schema files reference .constants - refer ‘./kharcha-tracker/constants.py’ for all ENUMs
# 16. Audit on GET: When calling get_record, Do Not create an audit log entry. Audit log entry must for delete-update-write operations only
