# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: sql_lite
# Status: unsplit
# Parent: storage_service
# Protocol: class
# Layout: file
# Contract version: 0.0.0
# Dependencies:
#   - storage_interface
