# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: base_record
# Status: stub
# Parent: schema
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0

# Notes:
# Captures all common columns present in any table schema
#
# These columns will be present in all columns. The 'is_deleted' is for soft deletion and will be usefull for data archiving. The 'created' and 'modofied' are for basic auditing. We can have an audit_log table for recording every time a table row is modified.
