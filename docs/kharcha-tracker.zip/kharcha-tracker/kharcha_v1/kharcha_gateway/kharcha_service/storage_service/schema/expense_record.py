# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: expense_record
# Status: stub
# Parent: schema
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0
