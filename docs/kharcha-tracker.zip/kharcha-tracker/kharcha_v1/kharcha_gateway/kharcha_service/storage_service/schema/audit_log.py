# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: audit_log
# Status: stub
# Parent: schema
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0

# Notes:
# "ID, actor_user_id, created_by, modified_by, entity_id use format: uuid per Python UUID serialization (JSON serializes UUIDs as strings)",
#   "created_at, modified_at, date_time use format: date-time per ISO 8601 datetime format",
#   "event, entity_type use string enum values matching the Python Enum .value property",
#   "All non-required fields use type: [type, null] to match Python Optional fields",
#   "old_value, new_value use union of primitive types and null to match Python Union[Type, None] serialization"
