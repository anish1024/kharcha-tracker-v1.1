# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: group_service
# Status: contract_defined
# Parent: kharcha_service
# Protocol: module
# Layout: file
# Contract version: 0.2.0
# Dependencies:
#   - group
#   - user
#   - audit_log
#   - storage_interface
#   - settlement_engine

# Notes:
# Groups and membership (FR-06..10). Every function takes storage first.
# SETTLED (after a FINAL settlement) is terminal: reject every mutation - members,
# invites, lock/unlock, delete, expenses - with ValueError.
# Not covered: FR-11 group notes (group model has no notes field).

# Exports declared by YAML:
#   - create_group
#   - list_groups_for_user
#   - get_group
#   - is_member
#   - generate_invite_code
#   - join_group_by_invite
#   - add_member
#   - leave_group
#   - lock_group
#   - unlock_group
#   - delete_group
#   - get_group_activity
