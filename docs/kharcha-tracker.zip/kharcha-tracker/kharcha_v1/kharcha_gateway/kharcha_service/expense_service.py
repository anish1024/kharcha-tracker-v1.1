# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: expense_service
# Status: contract_defined
# Parent: kharcha_service
# Protocol: module
# Layout: file
# Contract version: 0.2.0
# Dependencies:
#   - expense
#   - expense_share
#   - expense_payment
#   - storage_interface
#   - group_service
#   - expense_update

# Notes:
# Expense CRUD (FR-12..15). Every function takes storage first.

# Exports declared by YAML:
#   - add_expense
#   - list_group_expenses
#   - get_expense
#   - update_expense
#   - delete_expense
