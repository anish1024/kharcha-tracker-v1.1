# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: row_payout
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.3.0

# Notes:
# Internal, never persisted. Output of generate_row_payouts, input to consolidate_payouts. Frozen dataclass RowPayout inside settlement_engine.py.
