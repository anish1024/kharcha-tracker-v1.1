# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: notification
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.3.0

# Notes:
# One message to one user (FR-18).
