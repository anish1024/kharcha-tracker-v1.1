# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: base
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0

# Notes:
# Base DTO model that captures common fields like current login userid, login token, token expiry date-time.
