# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: expense_update
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.4.0

# Notes:
# Input to expense_service.update_expense (FR-15): descriptive fields only; None leaves a field unchanged. Amounts and splits are changed by delete + re-add.
