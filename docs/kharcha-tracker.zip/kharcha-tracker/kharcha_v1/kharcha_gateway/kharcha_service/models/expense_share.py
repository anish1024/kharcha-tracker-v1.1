# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: expense_share
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0

# Notes:
# DTO to capture split percentage among user (ids) who participate in particular expense. So user gets assigned percentage of total expense amount. Value of 100.00 means user paid for the entire expense. Value of 30.00 means user paid only 30 percent of the total expense 
