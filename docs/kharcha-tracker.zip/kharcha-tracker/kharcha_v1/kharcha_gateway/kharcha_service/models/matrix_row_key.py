# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: matrix_row_key
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.4.0

# Notes:
# Key of every expense-matrix row (expense or settled payout). Must be a frozen (hashable) dataclass because it is a dict key; str() gives expense:<trans_id> or payout:<id>. Never persisted.
