# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: payout
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.3.0

# Notes:
# A payout instruction or recorded payment between two group members. The payout table is the only record of payments: SETTLED, linked payouts are applied to the expense matrix as extra rows; nothing is written to the expense table.
