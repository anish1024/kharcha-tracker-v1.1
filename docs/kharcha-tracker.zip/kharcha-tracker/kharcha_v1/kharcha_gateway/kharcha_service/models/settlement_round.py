# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: settlement_round
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.2.0

# Notes:
# One settlement run (INDIVIDUAL / PERIODIC / FINAL) and the payouts it issued.
