# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: settlement_preview
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.2.0

# Notes:
# Frozen dataclass SettlementPreview inside settlement_engine.py; never persisted.
