# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: user
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0

# Notes:
# 'user' model captures all valid/active user logins in the system. The 'user' database table will also contain all in-active users (soft-deleted)
