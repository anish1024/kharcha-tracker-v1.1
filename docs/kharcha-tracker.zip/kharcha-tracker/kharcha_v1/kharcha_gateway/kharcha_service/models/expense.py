# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: expense
# Status: stub
# Parent: models
# Protocol: data-model
# Layout: file
# Contract version: 0.1.0

# Notes:
# DTO that captures all information required related to expense transaction.
