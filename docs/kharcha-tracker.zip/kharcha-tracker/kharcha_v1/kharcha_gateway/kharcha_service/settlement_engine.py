# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: settlement_engine
# Status: contract_defined
# Parent: kharcha_service
# Protocol: module
# Layout: file
# Contract version: 0.5.0
# Dependencies:
#   - storage_interface
#   - models
#   - constants
#   - notification_service
#   - expense_record
#   - payout_record
#   - settlement_round_record
#   - settlement_preview
#   - settlement_round
#   - settlement_error_code
#   - row_payout
#   - matrix_row_key

# Notes:
# File: kharcha_service/settlement_engine.py. Design and function reference: settlement_engine.md.
# Function leaves below are public. Private helpers (_group_state, _propose, _maybe_finalize, ...)
# are documented in settlement_engine.md only. DTOs live in models/, error codes in
# constants/settlement_error_code; every failure raises SettlementError(code, message).
# PRD 4.2.6 'Settlement Expense Record Creation' is retired: payments are derived from the
# payout table (apply_settled_payouts) and nothing is written to the expense table.
#
# * A group's balances live in ONE matrix, derived from two tables:
#     1. expense table  -> one row per expense (trans_id); columns = every group member.
#        Cell = paid - share: < 0 debt | > 0 overpaid | = 0 not involved.
#     2. payout table   -> one extra row per SETTLED, linked payout:
#        payor +amt (debt cleared), payee -amt (credit cleared).
#   Nothing is ever written to the expense table by settlement.
# * Per row, debtors pay the creditors of THAT row only; row-level instructions are then
#   consolidated into at most one payout per user PAIR (A->B and B->A netted).
# * Every payout lists the expense ids (trans_id) it was issued for. A combined payout
#   lists every expense that contributed to the pair's balance, in either direction.
#
# Settlement kinds (constants.settlement_kind), each persisted as a settlement_round:
#     INDIVIDUAL  settle_user(...)                    any time, group OPEN or LOCKED.
#     PERIODIC    initiate_settlement(kind=PERIODIC)  e.g. month end, group keeps running.
#     FINAL       initiate_settlement(kind=FINAL)     group LOCKED -> PARTIAL_SETTLEMENT ->
#                 SETTLED (closed for good) once every payout is SETTLED by its payee and
#                 every net due is 0. Re-running FINAL re-issues FAILED/CANCELLED amounts.
#
# Payout lifecycle (payor pays, payee receives; both are notified of every instruction):
#     PENDING --payor:  mark_payout_paid   (evidence optional)--> PAID     notify payee
#     PENDING --payee:  settle_payout      (cash / direct)------> SETTLED  notify payor
#     PAID    --payee:  settle_payout      (received)-----------> SETTLED  notify payor
#     PAID    --payee:  fail_payout        (not received)-------> FAILED   notify payor
#     PAID    --payor:  fail_payout        (transfer bounced)---> FAILED   notify payee
#     PENDING --payor/payee: cancel_payout ----------------------> CANCELLED notify other
#   SETTLED is final. FAILED and CANCELLED are final for that record and never forgive the
#   debt: the next settlement run re-issues the amount and the new payout lists the ones it
#   replaces in replaces_payout_ids. A reason is required for FAILED and CANCELLED.
#   Evidence is optional free text (bank reference or screenshot URL); payor and payee
#   each have their own slot. remind_payout nudges the party who has to act;
#   escalate_payout lets any member alert the whole group about a PAID payout the payee
#   has not reviewed within PAYOUT_ESCALATION_DAYS.
#
# Ad-hoc payments (record_adhoc_payment): recorded by the payor (-> PAID, payee reviews)
#   or by the payee (-> SETTLED). They count only once linked to at least one expense
#   that both users took part in; until then they are "orphans" with no effect.
#
# Commitment rule (why settlement runs never clash):
#     outstanding(pair) = pair net from the matrix - open payouts (PENDING or PAID, linked)
#   Runs only issue the outstanding remainder, so nobody is billed twice for money that is
#   owed, sent or awaiting review, and re-running a settlement with nothing new is a no-op.
#
# Money is computed in integer minor units (10**DECIMAL_PRECISION) throughout.
#
# Calling sequence:
# _group_state(storage, group)                              shared loader
#   _list_group_records(expense_record, payout_record)
#   -> build_expense_matrix -> apply_settled_payouts -> validate_matrix_balance
#   -> calculate_net_dues
# _propose(matrix, net_dues, open_payouts, all_payouts, group_id)   shared pure planner
#   generate_row_payouts (each row) -> consolidate_payouts(row_payouts, open_payouts)
#   -> _link_replacements -> _assert_payouts_reproduce_net_dues(proposed + open)
#
# preview_settlement            _group_state -> _propose            (writes nothing)
# settle_user                   _group_state -> _propose -> keep user's payouts
#                               -> create_settlement_round(INDIVIDUAL) -> notify both sides
# initiate_settlement(PERIODIC) _group_state -> _propose -> create_settlement_round
# initiate_settlement(FINAL)    orphan check -> _group_state -> _propose
#                               -> create_settlement_round(FINAL) -> PARTIAL_SETTLEMENT
#                               (or finalize_settlement when nothing is owed)
# mark_payout_paid / settle_payout / fail_payout / cancel_payout
#                               _load_payout (group open, role, state) -> save
#                               -> _complete_rounds -> notify -> _maybe_finalize
# record_adhoc_payment / link_payout_expenses
#                               _validate_links -> save -> notify -> _maybe_finalize
# _maybe_finalize               PARTIAL_SETTLEMENT, nothing open, no orphan SETTLED,
#                               all net dues 0 -> finalize_settlement -> group SETTLED

# Exports declared by YAML:
#   - preview_settlement
#   - list_payouts
#   - list_settlement_rounds
#   - settle_user
#   - initiate_settlement
#   - mark_payout_paid
#   - settle_payout
#   - fail_payout
#   - cancel_payout
#   - remind_payout
#   - escalate_payout
#   - record_adhoc_payment
#   - link_payout_expenses
