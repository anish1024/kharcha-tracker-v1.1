# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: expense_status
# Status: unsplit
# Parent: constants
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0

# Notes:
# Lifecycle status of an expense within its group. OPEN = still being added to, LOCKED = no further edits accepted, SETTLED = balances paid out.
#
# ENUM = ["Open", "Locked", "Settled"]
