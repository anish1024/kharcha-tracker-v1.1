# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: settlement_round_status
# Status: stub
# Parent: constants
# Protocol: data-model
# Layout: file
# Contract version: 0.2.0

# Notes:
# ACTIVE while any payout of the round is PENDING; FINAL rounds complete together with the group.
