# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: settlement_kind
# Status: stub
# Parent: constants
# Protocol: data-model
# Layout: file
# Contract version: 0.2.0

# Notes:
# INDIVIDUAL = one user clears dues any time; PERIODIC = group-wide (e.g. month end), group keeps running; FINAL = group-wide, closes the group (SETTLED).
