# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: expense_category
# Status: unsplit
# Parent: constants
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0

# Notes:
# Category applied to an expense for reporting/budgeting. See per-value notes for the exact OP_EXP vs CAP_EXP boundary, which is the one genuinely ambiguous distinction in this set.
#
# ENUM = ["GROCERY", "UTILITY", "TRAVEL", "ENTERTAINMENT", "FOOD_N_DINING", "OP_EXP", "CAP_EXP", "ACCOMMODATION", "CUSTOM"]
#
# # Standard Expenses
#
#     GROCERY = "Fruits, vegetables, toiletries, kitchen items, home decor, "
#
#     UTILITY = "electricity bills, phone bill, fuel, water and ay metered connections"
#
#     TRAVEL = "cab, rail tkt, bus, air tkt"
#
#     ENTERTAINMENT = "Movie, any subscriptions, fun activites"
#
#     FOOD_N_DINING = "Eating out, take-away"
#
#     OP_EXP = "Operating expenses like society Maintenance, allowances, maid salary, pest-control, replacing light bulbs, servicing HVAC/air conditioning units, and minor electrical work. Balcony gardening and Home decor like replacing bedsheets, cushions, curtains can be included here since it maintaining what is already present"
#     
#     CAP_EXP = "Long-term tangible items with a useful life of more than one year like Furniture & Fixtures like Desks, office chairs, sofas, dining tables, beds, and permanent lighting fixtures. Interior designing and structural changes made to a property you own or lease like False ceilings, built-in cabinetry, permanent flooring, safety doors and structural re-modeling. Minor home decor and design fees that do not add permanent structural value belong to OP_EXP like Cushions, rugs, paintings, temporary curtains, and standalone consultation fees for minor cosmetic refreshes"
#
#     ACCOMMODATION = "Rent, hotel, air-bnb, etc."
#     
# # Special Categories
#     # SETTLEMENT retired: user-to-user payments live in the payout table
#     CUSTOM = "Custom"         # Placeholder for user-defined expenses
