# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: payout_status
# Status: unsplit
# Parent: constants
# Protocol: data-model
# Layout: file
# Contract version: 0.3.0

# Notes:
# Lifecycle status of a payout instruction.
#   PENDING   issued, not yet sent
#   PAID      payor says the money was sent; awaiting the payee's review
#   SETTLED   payee confirmed receipt (final); only SETTLED, linked payouts move balances
#   FAILED    from PAID: payee did not receive it, or payor's transfer bounced (final;
#             the amount is re-issued by the next settlement run)
#   CANCELLED from PENDING, by payor or payee (final; the debt is not forgiven and is
#             re-issued by the next settlement run)
# ENUM = ["PENDING", "PAID", "SETTLED", "FAILED", "CANCELLED"]
