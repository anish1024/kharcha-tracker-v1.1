# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: settlement_error_code
# Status: stub
# Parent: constants
# Protocol: data-model
# Layout: file
# Contract version: 0.3.0

# Notes:
# Codes carried by settlement_engine.SettlementError(code, message), the only exception the
# engine raises. The HTTP status in each value's notes is applied by main
# (_SETTLEMENT_ERROR_STATUS), not by the engine.
