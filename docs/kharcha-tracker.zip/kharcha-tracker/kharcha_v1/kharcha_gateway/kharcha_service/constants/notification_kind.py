# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: notification_kind
# Status: stub
# Parent: constants
# Protocol: data-model
# Layout: file
# Contract version: 0.3.0

# Notes:
# Why a notification was sent (raised by settlement_engine through notification_service).
