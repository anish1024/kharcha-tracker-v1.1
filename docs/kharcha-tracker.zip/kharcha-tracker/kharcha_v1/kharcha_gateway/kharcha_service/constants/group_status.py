# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: group_status
# Status: unsplit
# Parent: constants
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0

# Notes:
# Lifecycle status of a group. PARTIAL_SETTLEMENT covers the case where some but not all members have settled their balances.
#
# ENUM = ["OPEN", "LOCKED", "SETTLED", "CANCELLED", "PARTIAL_SETTLEMENT"]
