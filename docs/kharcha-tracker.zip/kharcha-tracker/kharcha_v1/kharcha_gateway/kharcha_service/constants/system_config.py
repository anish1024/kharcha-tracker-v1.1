# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: system_config
# Status: unsplit
# Parent: constants
# Protocol: data-model
# Layout: file
# Contract version: 0.0.0

# Notes:
# Shared expense-module configuration constants.
#
# # Currency / Decimal Precision (Standard Finance: 2 decimal places)
# DECIMAL_PRECISION = 2
#
# # Floating Point Epsilon for Zero Sum Validation (Accounting Tolerance)
# # Used when checking if Net Debt Matrix Sum == 0
# FLOAT_EPSILON = 0.01
#
# # Transaction Limits (if applicable to your DB type)
# MAX_TRANSACTION_ID = 4294967295  # uint32 range
# MAX_GROUP_SIZE = 100           # Soft limit on group size
# MAX_PAYOUTS_PER_BATCH = 100     # Processing batch size
# PAYOUT_ESCALATION_DAYS = 7      # PAID payout unreviewed by the payee -> escalation allowed
