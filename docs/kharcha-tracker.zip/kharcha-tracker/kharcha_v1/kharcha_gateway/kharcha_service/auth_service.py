# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: auth_service
# Status: contract_defined
# Parent: kharcha_service
# Protocol: module
# Layout: file
# Contract version: 0.2.0
# Dependencies:
#   - user
#   - base
#   - storage_interface

# Notes:
# Users and tokens (FR-01..05). Every function takes storage first.
# Out of MVP scope: social login (FR-02), 2FA (FR-05).

# Exports declared by YAML:
#   - signup
#   - login
#   - request_password_reset
#   - confirm_password_reset
#   - get_current_user
#   - update_profile
