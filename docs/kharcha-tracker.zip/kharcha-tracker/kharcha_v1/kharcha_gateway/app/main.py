# kharcha-tracker YAML-derived artifact
# This file intentionally contains NO implementation code.
# It contains only metadata/notes derived from the source YAML.

# Node: main
# Status: contract_defined
# Parent: app
# Protocol: module
# Layout: file
# Contract version: 0.2.0
# Dependencies:
#   - auth_service
#   - group_service
#   - expense_service
#   - settlement_engine
#   - notification_service
#   - storage_interface
#   - storage_service
#   - models

# Notes:
# FastAPI app: kharcha_api/kharcha_gateway/app/main.py
# Run: uvicorn kharcha_api.kharcha_gateway.app.main:app  (KHARCHA_STORAGE=flat_file|sql_lite|postgres)
# Thin HTTP layer: request validation, bearer auth (auth_service.get_current_user), group
# membership check (group_service.is_member), error mapping. Business rules live in services.
# Missing service functions return 501 (listed by GET /api/v1/health).
#
# Endpoints (prefix /api/v1):
# GET    /health
# POST   /auth/signup                         FR-01, FR-03
# POST   /auth/login                          FR-01
# POST   /auth/password-reset/request         FR-04
# POST   /auth/password-reset/confirm         FR-04
# GET    /users/me                            FR-03
# PATCH  /users/me                            FR-03
# POST   /groups                              FR-06   (PRD)
# GET    /groups
# GET    /groups/{group_id}
# DELETE /groups/{group_id}                   FR-09
# POST   /groups/{group_id}/invite            FR-07   (PRD)
# POST   /groups/{group_id}/invite/accept     FR-07   (PRD)
# POST   /groups/{group_id}/members           FR-07   add a registered user by email
# DELETE /groups/{group_id}/members/me        FR-08   settle out / leave
# POST   /groups/{group_id}/lock              needed before settlement
# POST   /groups/{group_id}/unlock
# GET    /groups/{group_id}/activity          FR-10
# POST   /expenses                            FR-12/13 (PRD)
# GET    /groups/{group_id}/expenses
# GET    /expenses/{trans_id}
# PATCH  /expenses/{trans_id}                 FR-15
# DELETE /expenses/{trans_id}                 FR-15   (PRD)
# GET    /groups/{group_id}/settle            FR-16/17 (PRD) preview, read-only (?user_id=)
# POST   /groups/{group_id}/settle            FR-17   group-wide: PERIODIC (default) or FINAL
# POST   /groups/{group_id}/settle/me                 INDIVIDUAL: clear my dues any time
# GET    /groups/{group_id}/settlement-rounds         settlement history
# GET    /groups/{group_id}/payouts           FR-21   (?user_id=)
# POST   /groups/{group_id}/payouts/{payout_id}/paid       payor: money sent
# POST   /groups/{group_id}/payouts/{payout_id}/settled    payee: money received
# POST   /groups/{group_id}/payouts/{payout_id}/failed     payor or payee (from PAID)
# POST   /groups/{group_id}/payouts/{payout_id}/cancel     payor or payee (from PENDING)
# POST   /groups/{group_id}/payouts/{payout_id}/remind     FR-18
# POST   /groups/{group_id}/payouts/{payout_id}/escalate   any member, PAID > N days
# POST   /groups/{group_id}/payouts/{payout_id}/expenses   link an ad-hoc payment
# POST   /groups/{group_id}/payments          FR-20   record an ad-hoc payment
# GET    /users/me/payouts                            to pay / to receive, all groups
# GET    /users/me/notifications              FR-18   (?unread_only=)
# POST   /users/me/notifications/read
#
# lement kinds: INDIVIDUAL (one user, any time) and PERIODIC (e.g. month end) keep the
# p running. FINAL needs a LOCKED group and closes it for good (SETTLED) once every
# ut has been acknowledged (SETTLED) by its payee and nothing is owed.
# ut statuses: PENDING -> PAID (payor) -> SETTLED or FAILED (payee); PENDING ->
# ELLED (either). Role and state rules are enforced by settlement_engine.
